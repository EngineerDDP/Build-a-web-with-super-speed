using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SchoolManagement.Models;

namespace SchoolManagement.Controllers
{
    public class StuUserController : Controller
    {
        private readonly SchoolContext _context;
        private int currentid;
        public StuUserController(SchoolContext context)
        {
            _context = context;
        }
        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }
        /// <summary>
        /// 学生登录
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public async Task<ActionResult> Login(StuLoginViewModel model)
        {
            var student = await _context.Student.SingleOrDefaultAsync(
                q => q.ID == model.ID && q.Password == model.Password);
            if(student == null)
            {
                return View(model);
            }
            currentid = model.ID;
            return View("Index");
        }

        // GET: StuUser/Details/5
        public async Task<ActionResult> Index()
        {
            var student = await _context.Student
                .Include(s => s.Choices)
                .ThenInclude(c => c.Take)
                .AsNoTracking()
                .SingleOrDefaultAsync(m => m.ID == currentid);
            if (student == null)
            {
                return NotFound();
            }

            return View(student);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Choice(int id, int courseid)
        {
            var student = await _context.Student.SingleOrDefaultAsync(s => s.ID == id);
            var course = await _context.Lesson.SingleOrDefaultAsync(l => l.Id == courseid);

            student.Choices.Add(new Models.Choice()
            {
                Stu = student,
                Take = course,
                Score = 0
            });

            await _context.SaveChangesAsync();
            return View("Index");
        }

        // GET: StuUser/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: StuUser/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: StuUser/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: StuUser/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}